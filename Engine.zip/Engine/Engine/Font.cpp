#include "Engine.h"

Font::Font(char *name, int size, unsigned int color)
{
	m_name = name;
	m_size = size;
	m_color = color;


	HRESULT hResult = FW1CreateFactory(FW1_VERSION,
									&m_pFW1Factory);

	hResult = m_pFW1Factory->CreateFontWrapper(
							g_engine->GetDevice(),
							L"Arial",
							&m_pFontWrapper);


}

Font::~Font()
{
	m_pFontWrapper->Release();
	m_pFW1Factory->Release();
}

void Font::RenderString(char *text, float x, float y)
{
	const size_t cSize = strlen(text) + 1;
	wchar_t* wc = new wchar_t(cSize);
	mbstowcs(wc, text, cSize);

	m_pFontWrapper->DrawString(
		g_engine->GetDeviceContext(),
		wc,
		m_size,
		x,
		y,
		0xff0099ff,
		0);
}