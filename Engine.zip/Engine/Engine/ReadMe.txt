texture = {
	filename = ./Assets/Texture.dds,
	ignore_face = false,
	ignore_fog  = false,
	ignore_ray	= true,

transparency = {0.0, 0.0, 0.0, 0.0}

diffuse   =   {1.0, 1.0, 1.0, 1.0}
ambient   =    {1.0, 1.0, 1.0, 1.0}
specular  =    {1.0, 1.0, 1.0, 1.0}
emissive      {0.0, 0.0, 0.0, 0.0}
power     =     10.0
}