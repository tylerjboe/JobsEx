#pragma once

struct ViewerSetup
{
	unsigned long viewClearFlags;
	ViewerSetup()
	{
		viewClearFlags = 0;
	};
};

class State
{
public:
	State(unsigned long id = 0);

	virtual void Load();
	virtual void Close();

	virtual void RequestViewer(ViewerSetup *viewer);

	virtual void Update(float elapsed);
	virtual void Render(); // render state specific items

	unsigned long GetID();

private:
	unsigned long m_id; // app defined id must be unique

};

