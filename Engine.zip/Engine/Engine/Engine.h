//-----------------------------------------------------------------------------
// The primary engine header file. This file links the entire engine together
// and is the only header file that needs to be included in any project using
// the engine.
//
// Programming a Multiplayer First Person Shooter in DirectX
// Copyright (c) 2004 Vaughan Young
//-----------------------------------------------------------------------------
#ifndef ENGINE_H
#define ENGINE_H

//-----------------------------------------------------------------------------
// DirectInput Version Define
//-----------------------------------------------------------------------------
#define DIRECTINPUT_VERSION 0x0800

//-----------------------------------------------------------------------------
// System Includes
//-----------------------------------------------------------------------------
#include <stdio.h>
#include <tchar.h>
#include <Windows.h>
#include <windowsx.h>

//-----------------------------------------------------------------------------
// DirectX Includes
//-----------------------------------------------------------------------------
#include <dinput.h>
#include <d3d11.h>
#include <DirectXMath.h>
//#include <dplay8.h>
//#include <dmusici.h>
using namespace DirectX;


//-----------------------------------------------------------------------------
// Macros
//-----------------------------------------------------------------------------
#define SAFE_DELETE( p )       { if( p ) { delete ( p );     ( p ) = NULL; } }
#define SAFE_DELETE_ARRAY( p ) { if( p ) { delete[] ( p );   ( p ) = NULL; } }
#define SAFE_RELEASE( p )      { if( p ) { ( p )->Release(); ( p ) = NULL; } }

//-----------------------------------------------------------------------------
// Engine Includes
//-----------------------------------------------------------------------------
#include "LinkedList.h"
#include "ResourceManagement.h"
#include "Geometry.h"
#include "Input.h"
#include "State.h"
#include "Resource.h"
#include "Scripting.h"
#include "DeviceEnumeration.h"
#include "Font.h"

//-----------------------------------------------------------------------------
// Engine Setup Structure
//-----------------------------------------------------------------------------
struct EngineSetup
{
	HINSTANCE instance; // Application instance handle.
	char *name; // Name of the application.
	float scale;
	unsigned char totalBackBuffers;
	void(*StateSetup)();

	//-------------------------------------------------------------------------
	// The engine setup structure constructor.
	//-------------------------------------------------------------------------
	EngineSetup()
	{
		instance = NULL;
		name = "Application";
		scale = 1.0f;
		totalBackBuffers;
		StateSetup = NULL;
	}
};

//-----------------------------------------------------------------------------
// Engine Class
//-----------------------------------------------------------------------------
class Engine
{
public:
	Engine(EngineSetup *setup = NULL);
	virtual ~Engine();

	void Run();

	HWND GetWindow();
	void SetDeactiveFlag(bool deactive);

	ID3D11Device *GetDevice();
	ID3D11DeviceContext *GetDeviceContext();
	DXGI_MODE_DESC	*GetDisplayMode();

	Input *GetInput() { return m_Input; }
	State *GetCurrentState() { return m_currentState; }
	void AddState(State *state, bool change = true);
	void RemoveState(State *state);
	void ChangeState(unsigned long id);


private:
	bool m_loaded; // Indicates if the engine is loading.
	HWND m_window; // Main window handle.
	bool m_deactive; // Indicates if the application is active or not.

	EngineSetup *m_setup; // Copy of the engine setup structure.

	ID3D11Device *m_device; // video card interface
	D3D_FEATURE_LEVEL m_d3dFeatureLevel; // we can use from 9 to 11
	ID3D11DeviceContext* m_d3dDeviceContext;
	IDXGISwapChain* m_swapChain;

	D3D_DRIVER_TYPE m_driverType;
	ID3D11RenderTargetView*		m_backBufferTarget;

	DXGI_ADAPTER_DESC m_displayMode;

	unsigned char m_currentBackBuffer;



	LinkedList< State > *m_states;
	State *m_currentState;
	bool m_stateChanged;
	Input *m_Input;

};

//-----------------------------------------------------------------------------
// Externals
//-----------------------------------------------------------------------------
extern Engine *g_engine;

#endif