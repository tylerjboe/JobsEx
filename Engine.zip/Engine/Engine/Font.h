#pragma once

#include "..\FW1FontWrapper_1_1\FW1FontWrapper.h"

class Font
{
public: 
	Font(char *name = "Ariel", int size = 10,
		unsigned int color = 0xffffffff);

	virtual ~Font();

	void RenderString(char *text, float x, float y);

private:
	char *m_name;
	int m_size;
	unsigned int m_color;
	IFW1Factory *m_pFW1Factory;
	IFW1FontWrapper	*m_pFontWrapper;

};