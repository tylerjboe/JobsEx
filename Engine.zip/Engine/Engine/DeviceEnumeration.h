#ifndef DEVICE_ENUMERATION_H
#define DEVICE_ENUMERATION_H

//-----------------------------------------------------------------------------
// Display Mode Structure
//-----------------------------------------------------------------------------
struct DisplayMode
{
	DXGI_MODE_DESC mode; // Direct3D display mode.
	char bpp[6]; // Colour depth expressed as a character string for display.
};

//-----------------------------------------------------------------------------
// Device Enumeration Class
//-----------------------------------------------------------------------------
class DeviceEnumeration
{
public:
	INT_PTR Enumerate();  //removed device

	INT_PTR SettingsDialogProc(HWND dialog, UINT uiMsg, WPARAM wParam, LPARAM lParam);

	DXGI_MODE_DESC *GetSelectedDisplayMode();
	bool IsWindowed();
	bool IsVSynced();

private:
	void ComboBoxAdd(HWND dialog, int id, void *data, char *desc);
	void ComboBoxSelect(HWND dialog, int id, int index);
	void ComboBoxSelect(HWND dialog, int id, void *data);
	void *ComboBoxSelected(HWND dialog, int id);
	bool ComboBoxSomethingSelected(HWND dialog, int id);
	int ComboBoxCount(HWND dialog, int id);
	bool ComboBoxContainsText(HWND dialog, int id, char *text);

private:
	Script *m_settingsScript; // Script which stores the device configuration.

	IDXGIAdapter *m_pAdapter; //  adapter identifier.
	DXGI_ADAPTER_DESC adapterDesc;
	LinkedList< DisplayMode > *m_displayModes; // Linked list of enumerated display modes.
	DXGI_MODE_DESC m_selectedDisplayMode; // User selected display mode.
	bool m_windowed; // Indicates if the application should run in windowed mode.
	bool m_vsync; // Inidicates if v-sync should be enabled.
};

//-----------------------------------------------------------------------------
// Externals
//-----------------------------------------------------------------------------
extern DeviceEnumeration *g_deviceEnumeration;

#endif


//////////////////////////////////////////////////////////////////////////////////////////////////