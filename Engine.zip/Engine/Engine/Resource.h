//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDD_GRAPHICS_SETTINGS           144
#define IDC_DISPLAY_ADAPTER             1002
#define IDC_DISPLAY_FORMAT              1003
#define IDC_COLOUR_DEPTH                1003
#define IDC_RESOLUTION                  1004
#define IDC_REFRESH_RATE                1006
#define IDC_DRIVER_VERSION              1012
#define IDC_VSYNC                       1013
#define IDC_WINDOWED                    1016
#define IDC_FULLSCREEN                  1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
