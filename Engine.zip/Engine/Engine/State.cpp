#include "State.h"


State::State(unsigned long id)
{
	id = 0;
	m_id = id;
}

void State::Load(){}
void State::Close(){}

void State::RequestViewer(ViewerSetup *viewer){}
void State::Update(float elapsed){}
void State::Render(){} // render state specific items

unsigned long State::GetID()
{
	return m_id;
}

