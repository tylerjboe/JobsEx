#include "LuaScript.h"

LuaScript::LuaScript(const std::string& filename)
{
	L = luaL_newstate();
	luaL_loadfile(L, filename.c_str());
	lua_pcall(L, 0, 0, 0);

	if (L) luaL_openlibs(L);
}

LuaScript::~LuaScript()
{
	if (L) lua_close(L);
}

void LuaScript::printError(
	const std::string& variableName,
	const std::string& reason)
{
	std::cout << "Error: can't get["
			  << variableName << "]. "
			  << reason << std::endl;
}

std::vector<int> LuaScript::getIntVector(const std::string& name)
{
	std::vector<int> v;
	lua_gettostack(name.c_str());
	if (lua_isnil(L, -1))
	{
		// array not found
		return std::vector<int>();
	}

	lua_pushnil(L);
	
	while (lua_next(L, -2))
	{
		v.push_back((int)lua_tonumber(L, -1));
		lua_pop(L, 1);
	}

}

std::vector<std::string> 
			LuaScript::getTableKeys(const std::string& name)
{
	std::string luaCode =
		"function getKeys(name)"
		"s = \"\""
		"for k, v in pairs (_G[name]) do"
		" s = s..k..\",\""
		"end" // end of for
		"return s"
		"end"; // end of function

	luaL_loadstring(L, luaCode.c_str());
	lua_pcall(L, 0, 0, 0); // execute code in luaCode

	// get the loaded getKey function
	lua_getglobal(L, "getKeys");
	lua_pushstring(L, name.c_str()); // push table name on stack
	lua_pcall(L, 1, 1, 0);

	std::string test = lua_tostring(L, -1);
	
	std::cout << "Temp: " << test << std::endl;

	std::vector<std::string> strings;
	std::string temp;

	for (int i = 0; i < test.size(); i++)
	{
		if (test.at(i) != ',')
		{
			temp += test.at(i);
		}
		else{
			strings.push_back(temp);
			temp = "";
		}
	}
	clean(); // clean lua stack
	return strings;
}