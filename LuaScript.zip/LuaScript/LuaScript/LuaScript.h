// c++ program to interface with lua
#pragma once

#include <string>
#include <vector>
#include <iostream>

extern "C"
{
#include "..\lua\include\lua.h"
#include "..\lua\include\lualib.h"
#include "..\lua\include\lauxlib.h"
}

#pragma comment (lib, "..\\lua\\lua52.lib")

//class
class LuaScript
{
public:
	LuaScript(const std::string& filename);
	~LuaScript();

	void printError(const std::string& variable,
					const std::string& reason);

	std::vector<int> getIntVector(const std::string& name);
	std::vector<std::string> getTableKeys(const std::string& name);

	// cleans lua stack
	inline void clean()
	{
		// returns index to top element on stack
		// which also represents the number of elts
		// in stack
		int n = lua_gettop(L);
		lua_pop(L, n); // pop off all elements from stack
	}

	// get the value of a lua variable
	template < typename T >
	T get(const std::string& variableName)
	{
		if (!L)
		{
			printError(variableName, "Spcript not Loaded!");
			return lua_getDefault<T>();
		}

		T result;
		if (lua_gettostack(variableName)) // variable on stack
		{
			result = lua_get<T>(variableName);
		}
		else{
			// variable not on stack
			return lua_getDefault<T>();
		}
		clean();
		return result;
	}

	template<typename T>
	T lua_get(const std::string& variableName)
	{
		return 0;
	}

	template<typename T>
	T lua_getDefault()
	{
		return 0;
	}
///////////////////////////////////////////////////////////////////////////////////////////////////

	// look through this function and find the logic error
	// and figure out why there is one

	bool lua_gettostack(const std::string& variableName)
	{	// to access things like player.pos.x from
		// lua stack
		level = 0;
		std::string var = "";
		for (unsigned int i = 0; i < variableName.size(); i++)
		{
			if (variableName.at(i) == '.')
			{
				if (level == 0) // if this is the first word in var heirarchy
				{
					// get the top level object name and load
					// that object into the lua stack
					lua_getglobal(L, var.c_str());
				}
				else{
					// this is not a top level object, it is 
					// a member of the top level object
					// pushes the field onto the lua stackrf
					lua_getfield(L, -1, var.c_str());
				}
				if (lua_isnil(L, -1))
				{
					printError(variableName, var + "is not defined");
				}
				else
				{	// move to the next word in heirarchy
					var = "";
					level++;
				}
			} 
			else{
				// concatenate the letter
				var += variableName.at(i);
			}
		}
		return true;
	}

private:
	lua_State* L;
	std::string filename; // filename of our lua script
	int level;

};

// specializations
template <>
inline bool LuaScript::lua_get<bool>(const std::string& variableName)
{
	return (bool)lua_toboolean(L, -1);
}

template <>
inline float LuaScript::lua_get<float>(const std::string& variableName)
{
	if (!lua_isnumber(L, -1))
	{
		printError(variableName, "Not a number");
		return 0.0;
	}
	return (float)lua_tonumber(L, -1);
}

template <>
inline int LuaScript::lua_get<int>(const std::string& variableName)
{
	if (!lua_isnumber(L, -1))
	{
		printError(variableName, "Not a number");
		return 0;
	}
	return (int)lua_tonumber(L, -1);
}

template <>
inline std::string LuaScript::lua_get<std::string>(const std::string& variableName)
{
	std::string s = "null";
	if (lua_isstring(L, -1))
	{
		s = std::string(lua_tostring(L, -1));
	}
	else {
		printError(variableName, "Not a string");
	}
	return s;
}

template <>
inline std::string LuaScript::lua_getDefault<std::string>()
{
	return "null";
}