Skybox textures courtesy of The Mighty Pete.
Obtained from The Wadfather (http://www.planethalflife.com/wadfather/).
Used with permission.