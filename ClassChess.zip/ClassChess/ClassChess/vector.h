#pragma once

#include <math.h>

#define PI (3.14159265359f)
#define DEG2RAD(a) (PI/180*(a))
#define RAD2DEG(a) (180/PI*(a))

typedef float scalar_t;

class CVector
{
public:
	
	union
	{
		struct
		{
			scalar_t x;
			scalar_t y;
			scalar_t z;
		};
	scalar_t v[3];
	};

public:													 //shortcut
	CVector(scalar_t a =0, scalar_t b =0, scalar_t c = 0): x(a), y(b), z(c) {}
	CVector(const CVector &vec): x(vec.x), y(vec.y), z(vec.z){}

	//vector index
	scalar_t &operator[](const long idx)
	{
		return *((&x)+idx);
	}

	const CVector &operator=(const CVector &vec)
	{
		x = vec.x;
		y = vec.y;
		z = vec.z;

		return *this;
	}

	const bool operator ==(const CVector &vec) const
	{
		return ((x == vec.x) && (y == vec.y) && (z == vec.z));
	}

	const bool operator!=(const CVector &vec) const
	{
		return !(*this==vec);
	}


	const CVector operator+(const CVector &vec) const
	{
		return CVector(x + vec.x, y + vec.y, z + vec.z);
	}

	// vector add (opposite of negation)
	const CVector operator+() const
	{
		return CVector(*this);
	}

	const CVector operator-() const
	{
		CVector(-x,-y,-z);
	}

	//+= -(subtraction) -= *= /= * /
	// scalar  multiplication (CVector * number)
};