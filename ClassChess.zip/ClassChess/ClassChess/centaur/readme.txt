Centaur PPM for Quake2

Sagitarius - half man, half horse - license to shit in the streets.

'EVERYTHING HAS TWO LEGS!' I shouted about eight months ago whilst perusing the PMP. So I set about creating a Centaur. Not really interested in the standard type of centaur, I designed a blue one with hedgehog spines and a herbivorous head and antlers. OH FORTUNE! Why do you mock me by not including alpha channels in Quake2?

So, I made the Centaur with a flagrant disregard for the bounding box. Damn you bounding box! Damn! Actually it's arse sticks out a bit but not much.

I got half way through the blue skin and got distracted. I've been back to it occaisionally but it's been gathering dust at the back of my hard drive. Then someone mentioned multi-legged critters on the PMP message boards and I dug it out and finished it. 

This was my first attempt at using character studio and didn't do too bad I think.

The blue skin finally became the CTF blue skin and I made a boring brown one for the base skin. If anyone wants to do something more interesting, please feel free. I had in mind some Zebra camorflage, maybe.

Centaur PPM

Triangles	536
Skins		3 256x256
Team skins	yes (capture the flag red and blue).
Extra sounds	no
V-Wep		no

Made in 3D Studio MAX using Character Studio.
Skins made in Photoshop 5.0

To install,

unzip the zip file into the quake2/baseq2/players folder and it will automatically create a folder called Centaur and overarm the appropriate files into it.

Have fun,

Scarecrow

scarecrow@dial.pipex.com


'IT'S COMIN' RIGHT FOR US!!!!!'