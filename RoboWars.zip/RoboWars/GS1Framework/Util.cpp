#include <iostream> //io library
#include <string>	//string class
#include <fstream>	//file stream to write to log file
#include <ctime>	//to get current time
#include "Util.h"
using namespace std;

#define SIZE 26

void StartLog(void)
{
	time_t ltime;
	char buf[SIZE];
	errno_t err;
	time( &ltime );

	ofstream myFile;
	myFile.open("gamelog.txt");

	myFile << "Starting Log! /n";

	err = ctime_s(buf, SIZE, &ltime);

	if (err != 0)
	{
		myFile << "UTIL: Can't obtain time:" << err;
	}
	else 
	{
		myFile << "Log Started " << buf << endl;
	}

	myFile.close();
}

void LogString(string sLogString)
{
	time_t ltime;
	char buf[SIZE];
	errno_t err;
	time( &ltime );

	ofstream myFile;
	myFile.open("gamelog.txt");

	myFile << "Starting Log! /n";

	err = ctime_s(buf, SIZE, &ltime);

	if (err != 0)
	{
		myFile << sLogString << "time not found"  << endl;
	}
	else 
	{
		myFile << sLogString << " :" << buf << endl;
	}

	myFile.close();
}
