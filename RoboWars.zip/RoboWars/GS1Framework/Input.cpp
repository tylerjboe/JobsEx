#include "Input.h"
#include "Util.h"

#pragma comment (lib, "dinput8.lib")
#pragma comment (lib, "dxguid.lib")


CInput::CInput(HWND wHandle, HINSTANCE hInstance)
{
	HRESULT hr;
	// if FAILED(hr) {LogString("Error at . . .");}

	hr = DirectInput8Create(hInstance, DIRECTINPUT_VERSION, 
					   IID_IDirectInput8, (void**)&m_dInput, 0);

	// keyboard
	ZeroMemory(&m_KeyboardState, sizeof(m_KeyboardState));

	// set coop flags, indicate behavior of keyboard
	DWORD keyboardCoopFlags = DISCL_NONEXCLUSIVE | DISCL_FOREGROUND;

	hr = m_dInput->CreateDevice(GUID_SysKeyboard, &m_Keyboard, 0);
	hr = m_Keyboard->SetDataFormat(&c_dfDIKeyboard);
	hr = m_Keyboard->SetCooperativeLevel(wHandle, keyboardCoopFlags);
	hr = m_Keyboard->Acquire();

	//mouse
	ZeroMemory(&m_MouseState, sizeof(m_MouseState));

	// set coop flags, indicate behavior of keyboard
	DWORD mouseCoopFlags = DISCL_NONEXCLUSIVE | DISCL_FOREGROUND;

	hr = m_dInput->CreateDevice(GUID_SysMouse, &m_Mouse, 0);
	hr = m_Mouse->SetDataFormat(&c_dfDIMouse2);
	hr = m_Mouse->SetCooperativeLevel(wHandle, mouseCoopFlags);
	hr = m_Mouse->Acquire();

	//joystick
	ZeroMemory(&m_GamePadState, sizeof(m_GamePadState));
	m_GamePad = NULL;

	// Enumerate gamepads, they are sent to the callback
	// function. We only care about the first one
	// in the callback it will be created and assigned
	// to m_GamePad
	m_dInput->EnumDevices(DI8DEVCLASS_GAMECTRL, 
		::EnumJoysticksCallback, this, DIEDFL_ATTACHEDONLY);

	if (m_GamePad != NULL)
	{
		// Set coop flags, indicate behavior of keyboard
		DWORD GamePadCoopFlags = DISCL_EXCLUSIVE | DISCL_FOREGROUND;
		hr = m_GamePad->SetDataFormat(&c_dfDIJoystick2);
		hr = m_GamePad->SetCooperativeLevel(wHandle, GamePadCoopFlags);

		ZeroMemory(&m_GamePadCaps, sizeof(DIDEVCAPS));
		m_GamePadCaps.dwSize = sizeof(DIDEVCAPS);

		hr = m_GamePad->GetCapabilities(&m_GamePadCaps);

		// Determine hom many analog controls the device has
		hr = m_GamePad->EnumObjects(::EnumJoystickAxisCallback,
									this, DIDFT_AXIS);

		hr = m_GamePad->Acquire();
	}
}


CInput::~CInput(void)
{
	m_Keyboard->Unacquire();
	m_Mouse->Unacquire();
	if (m_GamePad != NULL)
	{
		m_GamePad->Unacquire();	
		SAFE_RELEASE(m_GamePad);
	}
	SAFE_RELEASE(m_Keyboard);
	SAFE_RELEASE(m_Mouse);
	SAFE_RELEASE(m_dInput);
}
