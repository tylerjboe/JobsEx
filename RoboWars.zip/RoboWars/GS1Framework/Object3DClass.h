#pragma once

#include <d3dx9.h>
#include <stdio.h>

#define RADIAN_TO_DEGREES 57.29577951308232286465f

class Object3DClass
{
public:
	LPD3DXMESH			pMesh;
	D3DMATERIAL9		*pMeshMaterials;
	LPDIRECT3DTEXTURE9	*pMeshTextures;
	DWORD				dwNumMaterial;
	LPD3DXBUFFER		pD3DXMtrlBuffer;
	LPDIRECT3DDEVICE9	pd3dDevice;

	Object3DClass(void);
	~Object3DClass(void);

	HRESULT hLoad(char *szName, LPDIRECT3DDEVICE9 p3d);
	void vCleanup();
	void DisplayXYZ(float x, float y, float z,
					float rx = 0.0f,
					float ry = 0.0f, 
					float rz = 0.0f);
};

