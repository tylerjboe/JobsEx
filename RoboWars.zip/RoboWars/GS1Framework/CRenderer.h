#ifndef _RENDERER_H
#define _RENDERER_H

#include "DataTypes.h"
#include "Util.h"
#include <d3d9.h>
#include <d3dx9.h>
#include <dxerr.h>
#include "Object3DClass.h"

class CGame;

class CRenderer
{
public:
	CRenderer(); //
	~CRenderer(); //
	bool RenderFrame(float dt);
	bool CleanUp();
	void setupPerspCamera();
	std::string sInputState;
	void DisplayInputState();
	void UpdateCamera();
	//void enableFullScreen(bool flip);

	D3DXMATRIX matProj;
	D3DXMATRIX matCameraView;
	D3DXVECTOR3 vecCameraSource; 
	D3DXVECTOR3 vecCameraTarget;

	LPDIRECT3DVERTEXBUFFER9 lpVertexBuffer;
	LPDIRECT3DTEXTURE9		g_pTexture[MAX_TEXTURES];
	MYVERTEX				g_Vertices[4];
	Object3DClass			o3dShop[13];
private:
	bool Init(); // initialize direct3D
	bool IsDeviceLost();
	void onLostDevice();
	void onResetDevice();
	void loadResources();
	void setupOrthoCamera();
	
	// member variables
	D3DPRESENT_PARAMETERS d3dpp;
	ID3DXFONT *genFont;
};

extern LPDIRECT3D9   pD3D; // main d3d object
extern LPDIRECT3DDEVICE9 pd3dDevice; // video card device object
extern CGame *gGame;

#endif