//Startup for app
#include <windows.h>
#include "Game.h"

CGame *gGame;

int WINAPI WinMain(HINSTANCE hInstance,
				   HINSTANCE hPrevInstance,
				   LPSTR lpCmdLine,
				   int nCmdShow)
{
	StartLog();
	gGame = new CGame();
	gGame->Init(hInstance);
	gGame->Run();
	delete gGame;
	LogString("Ending Program");

	return 0;
}