#include "network.h"
#include "DXUTIL.h"

HANDLE				gConnectCompleteEvent;
HRESULT				gConnectComplete;
CRITICAL_SECTION	gModifyPlayer;

Network::Network()
{
	pDP							= NULL;
	pDeviceAddress				= NULL; //us
	pHostAddress				= NULL;   //our host
	hConnectAsycOp				= NULL;
	dpnidLocalPlayer			= NULL;

	for(int i = 0; i < MAX_PLAYERS; i++)
	{
		PlayerInfo[i].bActive = false;    
	}


	iMyPlayerId					= 0; //subscript into player
	iNumberOfActivePlayers		= 0;
	bHost						= false; // are we the Host?
}

Network::Network()
{
	SAFE_RELEASE(pDP);
	SAFE_RELEASE(pDeviceAddress); //us
	SAFE_RELEASE(pHostAddress);   //our host
	hConnectAsycOp   = NULL;
	dpnidLocalPlayer = NULL;

}

bool Network::Initialize(HWND hWnd)
{
	HRESULT hResult;
	//there is no special function to create the main directPlay
	//object. we have to use the generic com creation function

	//first initialize COM
	hResult = CoInitialize(NULL);
	if(FAILED(hResult))
	{
		LogString("ErrorInitializing COM. DirectPlayError");
		return false;
	}

	//code to ensure two processes aren't trying to change shared memory at the same time
	//not the lock, jus tthe initialization
	InitializeCriticalSection(&gModifyPlayer);

	EnterCriticalSection();
	LeaveCriticalSection();

	//create the main DirectPlay COM object
	hResult = CoCreateInstance(CLSID_DirectPlay8Peer, //class to create
							   NULL, //extra creation params
							   CLSCTX_INPROC_SERVER, //object runs in this programs memory space
							   IID_IDirectPlay8Peer, //interface id
							   (LPVOID*)&pDP);
	
	if(FAILED(hResult))
	{
		LogString("Network::Initialize Cannot Create DirectPlayPeer");
		return false;
	}

	//set up the message handler
	//indicating which function will handle network messages
	hResult = pDP->Initialize(NULL, DirectPlayMessageHandler, 0);

	if (FAILED(hResult))
	{
		LogString("Network::Unable to initialize message handler.");
		return false;
	}


	//create our network device COM object pDeviceAddress
	hResult = CoCreateInstance(CLSID_DirectPlay8Address, //class to create
							   NULL, //extra creation params
							   CLSCTX_INPROC_SERVER, //object runs in this programs memory space
							   IID_IDirectPlay8Address, //interface id
						       (LPVOID*)&pDeviceAddress);	
	if (FAILED(hResult))
	{
		LogString("Network::Unable to create device address.");
		return false;
	}

	//set up service provider for DirectPlay to TCP/IP

	hResult = pDeviceAddress->SetSP(&CLSID_DP8SP_TCPIP);

	if (FAILED(hResult))
	{
		LogString("Network::Unable to set provider for our device.");
		return false;
	}

	//create our host network device COM object pDeviceAddress
	hResult = CoCreateInstance(CLSID_DirectPlay8Address, //class to create
							   NULL, //extra creation params
							   CLSCTX_INPROC_SERVER, //object runs in this programs memory space
							   IID_IDirectPlay8Address, //interface id
						       (LPVOID*)&pHostAddress);	
	if (FAILED(hResult))
	{
		LogString("Network::Unable to create device address.");
		return false;
	}

	//set up service provider for DirectPlay to TCP/IP

	hResult = pHostAddress->SetSP(&CLSID_DP8SP_TCPIP);

	if (FAILED(hResult))
	{
		LogString("Network::Unable to set provider for our host.");
		return false;
	}
	
	//TODO: create connection completion event
	gConnectCompleteEvent = CreateEvent(NULL, //attributes
										FALSE, //manual reset
										FALSE, //initial state
										NULL); //name


	return true;
}

//to join a session, you need the player information, the application description, and the host address
HRESULT Network::JoinGame(HWND hWnd)
{
	HRESULT					hResult = S_OK;
	WCHAR					wszHostName[256];
	WCHAR					wszPeerName[256];
	char					szPeerName[256];
	char					szIP[256];
	DWORD					dwPort;
	DWORD					dwLength = 256;
	DPN_APPLICATION_DESC	dpnAppDesc;
	DPN_PLAYER_INFO			dpnPlayerInfo;

	FILE *fp = fopen("config.txt", "r");
	fgets(szIP, 17, fp); //read 16 chars from file and store in szIP
	szIP[strlen(szIP)-1] = '\0';
	fgets(szPeerName, 32, fp);
	szPeerName[strlen(szPeerName)-1] = '\0';
	fclose(fp); //close the file

	//set the peer info
	DXUtil_ConvertGenericStringToWideCch(wszPeerName, szPeerName, 0);

	ZeroMemory(&dpnPlayerInfo, sizeof(DPN_PLAYER_INFO));
	dpnPlayerInfo.dwSize = sizeof(DPN_PLAYER_INFO);
	dpnPlayerInfo.dwInfoFlags = DPNINFO_NAME;
	dpnPlayerInfo.pwszName = wszPeerName;

	//assign peer information to the local direct play object
	hResult = pDP->SetPeerInfo(&dpnPlayerInfo, NULL, NULL, DPNSETPEERINFO_SYNC);

	if(FAILED(hResult))
	{
		return false;
	}

	//prepare the application description
	ZeroMemory(&dpnAppDesc, sizeof(DPN_APPLICATION_DESC));
	dpnAppDesc.dwSize = sizeof(DPN_APPLICATION_DESC);
	dpnAppDesc.guidApplication = DP_ROBOWARS;

	//set up the host address
	DXUtil_ConvertGenericStringToWide(wszHostName, szIP);

	dwPort = 9000;

	hResult = pHostAddress->AddComponent(DPNA_KEY_HOSTNAME, 
										wszHostName, 
										(wcslen(wszHostName) + 1)*sizeof(WCHAR),  //size of host name in bytes
										DPNA_DATATYPE_STRING);
	if(FAILED(hResult))
	{
		LogString("JOIN: Could not assign IP to host address");
		return false;
	}

	//add the port to pHostAddress
	hResult = pHostAddress->AddComponent(DPNA_KEY_PORT, &dwPort, sizeof(DWORD), DPNA_DATATYPE_DWORD);

	if(FAILED(hResult))
	{
		LogString("JOIN: Could not assign Port to host address");
		return false;
	}

	hResult = pDP->Connect(&dpnAppDesc,
						   pHostAddress,
						   pDeviceAddress,
						   NULL, //must be null reserved
						   NULL, //must be null reserved
						   NULL, //app sepcific data for validation
						   0, //data size of prev param
						   NULL, //player context optional
						   NULL, //user context optional
						   &hConnectAsycOp, //OUT: handle we can use to cancel ops
						   NULL); //flags, host function has same flags
	
	if (hResult != E_PENDING && FAILED(hResult))
	{
		return false;
	}

	SetTimer(hWnd, TIMERID_CONNECT_COMPLETE, 100, NULL);

	return hResult;
}
HRESULT Network::HostGame(HWND hWnd)
{
	HRESULT					hResult = S_OK;
	WCHAR					wszSessionName[256];
	WCHAR					wszPeerName[256];
	char					szPeerName[256];
	char					szSessionName[256];
	char					szIP[256];
	DWORD					dwPort;
	DWORD					dwLength = 256;

	DPN_APPLICATION_DESC	dpnAppDesc;
	DPN_PLAYER_INFO			dpnPlayerInfo;

	FILE *fp = fopen("config.txt", "r");
	fgets(szIP, 17, fp); //read 16 chars from file and store in szIP
	szIP[strlen(szIP)-1] = '\0';
	fgets(szPeerName, 32, fp);
	szPeerName[strlen(szPeerName)-1] = '\0';
	fclose(fp); //close the file

	//set the peer info
	DXUtil_ConvertGenericStringToWideCch(wszPeerName, szPeerName, 0);

	ZeroMemory(&dpnPlayerInfo, sizeof(DPN_PLAYER_INFO));
	dpnPlayerInfo.dwSize = sizeof(DPN_PLAYER_INFO);
	dpnPlayerInfo.dwInfoFlags = DPNINFO_NAME;
	dpnPlayerInfo.pwszName = wszPeerName;

	//assign peer information to the local direct play object
	hResult = pDP->SetPeerInfo(&dpnPlayerInfo, NULL, NULL, DPNSETPEERINFO_SYNC);

	if(FAILED(hResult))
	{
		return false;
	}

	//prepare the application description
	sprintf(szSessionName, "%s's Game", szPeerName);
	DXUtil_ConvertGenericStringToWide(wszSessionName, szSessionName);
	
	ZeroMemory(&dpnAppDesc, sizeof(DPN_APPLICATION_DESC));
	dpnAppDesc.dwSize = sizeof(DPN_APPLICATION_DESC);
	dpnAppDesc.guidApplication = DP_ROBOWARS;
	dpnAppDesc.pwszSessionName = wszSessionName;
	dpnAppDesc.dwMaxPlayers = MAX_PLAYERS;
	dpnAppDesc.dwFlags = DPNSESSION_MIGRATE_HOST;


	dwPort = 9000;

	//add the port to pHostAddress
	hResult = pHostAddress->AddComponent(DPNA_KEY_PORT, &dwPort, sizeof(DWORD), DPNA_DATATYPE_DWORD);

	if(FAILED(hResult))
	{
		LogString("JOIN: Could not assign Port to host address");
		return false;
	}

	hResult = pDP->Host(&dpnAppDesc,
						   &pDeviceAddress,
						   1,
						   NULL, //must be null reserved
						   NULL, //must be null reserved
						   NULL, //player context optional
						   NULL); //flags, host function has same flags
	
	if (FAILED(hResult))
	{
		LogString("HOST: Could not host");
		return false;
	}

	bHost = true;
	//TODO: send a system message "Hosting"

	return hResult;
}

int	Network::iAddPlayer(DPNID dpid, D3DXVECTOR3 pos, float fRot, char *szName)
{
	//search the player info array to see if there is a spot for a new player
	int i;
	for(i = 0; i < MAX_PLAYERS; i++)
	{
		if(PlayerInfo[i].bActive == false)
		{
			break;
		}
	}

	if(i >= MAX_PLAYERS)
	{
		return -1;
	}

	PlayerInfo[i].bActive = true;
	PlayerInfo[i].dpnidPLayer = dpid;
	PlayerInfo[i].fRot = fRot;
	PlayerInfo[i].fVelocity = 0.0;
	PlayerInfo[i].iFrame = 0;
	PlayerInfo[i].iScore = 0;
	strcpy(PlayerInfo[i].szPlayerName, szName);
	PlayerInfo[i].vecCurPos = pos;
	PlayerInfo[i].vecLastPos = pos;

	return i;
}

HRESULT Network::CreatePlayer(PVOID pvUserContext, PVOID pMsgBuffer)
{
	HRESULT					hResult = S_OK;
	PDPNMSG_CREATE_PLAYER	pCreatePlayerMsg;
	DPN_PLAYER_INFO			*pdpPlayerInfo = NULL;
	DWORD					dwSize = 0;

	//get a pointer to the msg buffer in correct format
	pCreatePlayerMsg = (PDPNMSG_CREATE_PLAYER)pMsgBuffer;

	hResult = pDP->GetPeerInfo(pCreatePlayerMsg->dpnidPlayer, //player ID
					 pdpPlayerInfo, //dummy param for now
					 &dwSize, //size of retrieved data
					 0); //extra flags
	if(FAILED(hResult) && hResult != DPNERR_BUFFERTOOSMALL)
	{
		return -1;
	}
	else
	{
		//allocate memory for pdpPlayerInfo 
		pdpPlayerInfo = (DPN_PLAYER_INFO*) new BYTE [dwSize];
		ZeroMemory(pdpPlayerInfo,  dwSize);

		//and call GetPeerInfo again to grab the data
		pDP->GetPeerInfo(pCreatePlayerMsg->dpnidPlayer, //player ID
						 pdpPlayerInfo, //returned info
						 &dwSize, //size of retrieved data
						 0); //extra flags

		if(FAILED(hResult))
		{
			return -1;
		}

		//we have the player information, now we can add them
		//we are going to be accessing shared memory, so we need a lock
		EnterCriticalSection(&gModifyPlayer);

		//convert the player's name to ANSI from Unicode
		char strName[256];
		DXUtil_ConvertWideStringToGeneric(strName, pdpPlayerInfo->pwszName);

		//check to see if we are adding ourself
		if (pdpPlayerInfo->dwPlayerFlags & DPNPLAYER_LOCAL) //player is us
		{
			dpnidLocalPlayer = pCreatePlayerMsg->dpnidPlayer;
			iMyPlayerId = iAddPlayer(dpnidLocalPlayer, D3DXVECTOR3(0.0f, 0.0f, 0.0f), 0.0f, strName);
		}
		else //player is not us
		{
			int i = iAddPlayer(pCreatePlayerMsg->dpnidPlayer, D3DXVECTOR3(0.0f, 0.0f, 0.0f), 0.0f, strName);

			//if were the host, send a welcom to game message to the player (just the player)
			if (bHost == true)
			{
				char szOutput[256];
				sprintf(szOutput, "Welcome To Game, %s!", strName);

				PacketChat ChatMsg;
				void *packet; 
				ChatMsg.dwSize = sizeof(PacketChat);
				ChatMsg.dwType = PACKET_TYPE_CHAT;
				strcpy(ChatMsg.szText, szOutput);
				packet = (VOID*)&ChatMsg;
				hResult = SendPeerMessage(i, PACKET_TYPE_CHAT, packet);
			}
			//TODO: send a system message indicating player has joined
		}

		SAFE_DELETE_ARRAY(pdpPlayerInfo);
		InterlockedIncrement(&lNumberOfActivePlayers);

		LeaveCriticalSection(&gModifyPlayer);
	}

	return hResult;
}

HRESULT Network::DestroyPlayer(PVOID pvUserContext, PVOID pMsgBuffer)
{
	HRESULT					hResult = S_OK;
	PDPNMSG_DESTROY_PLAYER	pDestroyPlayerMsg;
	DPN_PLAYER_INFO			*pdpPlayerInfo = NULL;
	DWORD					dwSize = 0;

	//get a pointer to the msg buffer in correct format
	pDestroyPlayerMsg = (PDPNMSG_DESTROY_PLAYER)pMsgBuffer;

	hResult = pDP->GetPeerInfo(pDestroyPlayerMsg->dpnidPlayer, //player ID
					 pdpPlayerInfo, //dummy param for now
					 &dwSize, //size of retrieved data
					 0); //extra flags

	return hResult;
}

//called from all the update functions, the render and from winmain and the game loop
HRESULT Network::SendPeerMessage(int player, DWORD dwMessageType, PVOID pMsgBuffer)
{
	DPNHANDLE	hAsyc;
	DWORD		dwLength;
	DPN_BUFFER_DESC	bufferDesc;
	PacketGeneric	*PGen;

	//place the message in the generic buffer to get the size
	PGen = (PacketGeneric*)pMsgBuffer;
	dwLength = PGen->dwSize;

	if(dwLength == 0)
	{
		return (0); //return if empty packet
	}

	bufferDesc.dwBufferSize = dwLength;
	bufferDesc.pBufferData = (BYTE*) pMsgBuffer;

	//send the message to everyone or specific player
	if(player == -1) //everyone
	{
		pDP->SendTo(DPNID_ALL_PLAYERS_GROUP, &bufferDesc, 1, 0, NULL, &hAsyc, 0);
	}
	else
	{
		pDP->SendTo(PlayerInfo[player].dpnidPLayer, &bufferDesc, 1, 0, NULL, &hAsyc, 0);
	}

	return S_OK;
}