#pragma once

#include "WindowClass.h"
//#include "CRenderer.h"
#include "Util.h"
#include <fstream>
#include <iostream>
#include "network.h"
#include "Input.h"

class CRenderer;

class CGame
{
public:
	// enum datatype {possibleVal1, possibleVal2, ...}
	enum GameState {GAMELOADING, GAMERUNNING, GAMEPAUSE, GAMESTOPPED };

	CGame(void) {gWin = NULL; gRenderer = NULL;} //CInput = NULL;
	~CGame(void);

	WindowClass	*gWin;
	CRenderer	*gRenderer;
	CInput		*gInput;
	Network		*gNetwork;

	//class variables
	bool bFireBullet;
	bool bTurnLeft;
	bool bTurnRight;
	bool bAccelerate;
	bool bDecelerate;

	GameState m_GameState;

	bool Init (HINSTANCE hInstance);
	bool ProcessGame(float dt);
	bool Run();
	bool CleanUp();
	bool UpdateObjects(float dt);
	void CreateBullet(DPNID dpowner, float fx, float fz, float fvel, float frot);
private:
	bool GameLoop();
};

