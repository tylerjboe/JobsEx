//misc utilities and macros
#ifndef __JEREMYUTIL_H
#define __JEREMYUTIL_H

#include <string>
#include <sstream>
#include <iomanip>

void StartLog(void);
void LogString(std::string sLogString);

//function to convert any datatype to string
template <class T> //T is the datatype parameter
std::string stringify(T foo)
{
	//this function takes whatever is passed in foo
	//and converts it to a string and returns it
	std::ostringstream sstr; // a simple string
	sstr.flags(std::ios::fixed);
	sstr << std::setprecision(5);
	sstr << " " << foo << " ";
	std::string retString = sstr.str();
	return retString;
}

#define SAFE_DELETE(p){if (p){delete (p);(p) = NULL;}}
#define SAFE_DELETE_ARRAY(p){if (p){delete [] (p);(p) = NULL;}}
#define SAFE_RELEASE(p){if (p){(p)->Release();(p) = NULL;}}


#endif