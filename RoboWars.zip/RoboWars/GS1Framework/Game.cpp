#include "Game.h"
#include "CRenderer.h"

__int64 cntsPerSec;
__int64 prevTimeStamp;
float secsPerCount;

CGame::~CGame(void)
{
}

// called from event loop, will run once per cycle
// will make function calls to get input, process the game
// and draw a frame
bool CGame::GameLoop()
{
	// get the current timestamp
	__int64 currTimeStamp = 0;
	QueryPerformanceCounter((LARGE_INTEGER*)&currTimeStamp);
	// calculate how much time in seconds has elapsed
	//  since the last time we called GameLoop
	float dt = (currTimeStamp - prevTimeStamp) * secsPerCount;

	// get the input
	gRenderer->sInputState = gInput->getGamePadStateString();
	gInput->poll();
	ProcessGame(dt);
	gRenderer->RenderFrame(dt);
	prevTimeStamp = currTimeStamp;
	return true;
}
// do game logic
bool CGame::ProcessGame(float dt)
{
	if(gInput->keyDown(DIK_DOWN));
	{
		bDecelerate = true;
	}
	if(gInput->keyDown(DIK_UP));
	{
		bAccelerate = true;
	}
	if(gInput->keyDown(DIK_LEFT));
	{
		bTurnLeft = true;
	}
	if(gInput->keyDown(DIK_RIGHT));
	{
		bTurnLeft = true;
	}
	if(gInput->keyDown(DIK_SPACE));
	{
		bFireBullet = true;
	}

	//update the objects
	UpdateObjects(dt);

	//update network
	//UpdateNetwork();
	return true;
}

bool CGame::Init(HINSTANCE hInstance)
{
	m_GameState = GAMESTOPPED;
	LogString("CGame::Init - Initializing Game");
		
	gWin = new WindowClass(hInstance, 1024, 768, 
		                   false, "GS1Game");

	if (gWin == NULL)
	{
		LogString("Error Creating Window");
		return false;
	}

	gRenderer = new CRenderer();


	if (gRenderer == NULL)
	{
		LogString("Could not create Renderer");
		return false;
	}

	m_GameState = GAMERUNNING;
	LogString("GameRunning");

}

bool CGame::Run()
{
	MSG msg;
	ZeroMemory(&msg, sizeof(MSG));

	// initialize timer variables
	cntsPerSec = 0; // every machine has its own counts per sec
	prevTimeStamp = 0;
	QueryPerformanceFrequency((LARGE_INTEGER*)&cntsPerSec);
	QueryPerformanceCounter((LARGE_INTEGER*)&prevTimeStamp);
	secsPerCount = 1.0f / (float)cntsPerSec; // its easier to think in seconds or fractions of a second



	LogString("Entering Main Message Loop");
	while (msg.message != WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		} else {
			switch (m_GameState) {
			case GAMERUNNING:
				GameLoop();
				break;
			case GAMESTOPPED:
				PostQuitMessage(0);
				break;
			default:
				break;
			}
		}
	}
	CleanUp();
	return true;
}

bool CGame::UpdateObjects(float dt)
{
	//updates our game objects for each frame of animation
	float			fx, fz;
	int				iHighestScoreHolder, lHighestScore;
	bool			bKillBullet = false;
	static float	fElapsed;
	float			fMultiplier;
	PacketAngle		pacAngle;
	PacketVelocity	pacVel;
	HRESULT			hResult;
	void			*packet;

	fMultiplier = dt / 33.0f;

	//updates consist of updating objects based on user input and notifying other players of our update

	if(bAccelerate)
	{
		bAccelerate = false;
		//player will have a max velocity of 2.0f
		//we will only move the local player by changing velocity (+1)
		//the actual update of position will happen elsewhere
		if(PlayerInfo[gNetwork->iMyPlayerId].fVelocity < 2.0f)
		{
			PlayerInfo[gNetwork->iMyPlayerId].fVelocity += 1.0f;

			//notify other players of the change in velocity
			pacVel.dwSize = sizeof(PacketVelocity);
			pacVel.dwType = PACKET_TYPE_VELOCITY;
			pacVel.fVelocity - PlayerInfo[gNetwork->iMyPlayerId].fVelocity;

			packet = (VOID*)&pacVel;

			hResult = gNetwork ->SendPeerMessage(-1, PACKET_TYPE_VELOCITY, packet);
		}


		
		//decelerate min speed - 1

		//rotate left - 10 each rotation
		//keep in range 0 - 360

		//rotate right + 10 each rotation
		//keep in range

		//bullet, call CreateBullet

		for(int i = 0; i < MAX_BULLETS; i++)
		{
			if(Bullet[i].bActive == true)
			{
				bKillBullet = false;
				double fRad;
				fRad = DegToRad(Bullet[i].fRot);
				fz = (float)cos(fRad);
				fx = (float)sin(fRad);

				fx *= fMultiplier;
				fz *= fMultiplier;

				Bullet[i].fx += (float)(fx*Bullet[i].fVelocity)*-1;
				Bullet[i].fz += (float)(fz*Bullet[i].fVelocity)*-1;

				if(Bullet[i].fx > ARENA_SIZE)
				{
					Bullet[i].fx = ARENA_SIZE;
		

			//check if the bullet hits a player
			//+- 15 units to hit a player
			for(int j = 0; j < MAX_PLAYERS; j++)
			{
				if(PlayerInfo[j].bActive)
				{
					if(abs((int)Bullet[i].fz - (int)PlayerInfo[i].vecCurPos.z) < 15)
					{
						if(abs((int)Bullet[i].fx - (int)PlayerInfo[i].vecCurPos.x) < 15)
						{
							//bullet has struck player
							bKillBullet = true;
							//if its our bullet, update our score
							if(Bullet[i].dpOwner == gNetwork->dpnidLocalPlayer)
							{
								PlayerInfo[gNetwork->iMyPlayerId].lScore += 100;
							}
							break; //bullet can only strike one player
						}	
					}
				}
			}//end of j MAX_PLAYERS
			//if bullet hits something create an explostion
			if(bKillBullet == true)
			{
				Bullet[i].bActive = false;
				bKillBullet = false;
				
				for(j = 0; j < MAX_EXPLOSIONS; j++)
				{
					if (Explosion[j].bActive == false)
					{
						Explosion[j].bActive = true;
						Explosion[j].fx = Bullet[i].fx;
						Explosion[j].fz = Bullet[i].fz;
						Explosion[j].iFrame = 0;
						Explosion[j].dwFrameTime = 0;
						//play explosion sound
						break;
					}
				}


			}
		}
	}
	
	//update animation for explosions

	//loop through explosions
	for(int n = 0; n < MAX_EXPLOSIONS; n++)
	{
		//update active ones
		if(Explosion[n].bActive == true)
		{
			Explosion[n].dwFrameTime += dt;

			//if enough time has passed, advance frame
			//there are 8 total frames
			if(Explosion[n].dwFrameTime > .5)
			{
				Explosion[n].iFrame++;
				Explosion[n].dwFrameTime = 0;

				if(Explosion[n].iFrame >= 8)
				{
					Explosion[n].bActive = false;
				}
			}
		}
	}

	//TODO: update the player who has the highest score
}

void CGame::CreateBullet(DPNID dpowner, float fx, float fz, float fvel, float frot)
{
	PacketBullet	pacBUl;
	void			*packet;
	HRESULT			hResult;
	int i;

	for(i = 0; i < MAX_BULLETS; i++)
	{
		if(Bullet[i].bActive == false)
		{
			break;
		}
	}

	if(i == MAX_BULLETS)
	{
		return; //no room in array at this time for bullet
	}

	Bullet[i].bActive = true;
	Bullet[i].fx = fx;
	Bullet[i].fz = fz;
	Bullet[i].Velocity = fvel + 3.0f;
	Bullet[i].dpOwner = dpowner;
	Bullet[i].fRot = frot;

	//play fire sound

	//only send packet if you are owner
	//if we are not the owner we are donw
	if(dpowner == gNetwork->dpnidLocalPlayer)
	{
		pacBul.dwSize = sizeof(PacketBullet);
		pacBul.dwType = PACKET_TYPE_BULLET;
		pacBul.Bullet.bActive = true;
		pacBul.Bullet.dpOwner = dpowner;
		pacBul.BUllet.fRot = frot;
		pacBul.Bullet.fVelocity = fvel;
		pacBul.Bullet.fx = fx;
		pacBul.Bullet.fz = fz;

		packet = (VOID*)&pacBul;
		hResult = gNetwork->SendPeerMessage(-1, PACKET_TYPE_BULLET, packet);
	}
}

bool CGame::CleanUp()
{
	SAFE_DELETE(gRenderer);
	SAFE_DELETE(gWin);
	return true;
}


