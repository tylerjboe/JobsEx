#include "Object3DClass.h"
#include "Util.h"

Object3DClass::Object3DClass(void)
{
	pMesh = NULL;
	pMeshMaterials = NULL;
	pMeshTextures = NULL;
	dwNumMaterial = 0;
	pD3DXMtrlBuffer = NULL;
	pd3dDevice = NULL;
}


Object3DClass::~Object3DClass(void)
{
	vCleanup();
}

void Object3DClass::vCleanup()
{
	SAFE_RELEASE(pMesh);
	SAFE_DELETE_ARRAY(pMeshMaterials);
	SAFE_DELETE_ARRAY(pMeshTextures);
	SAFE_RELEASE(pD3DXMtrlBuffer);
}

HRESULT Object3DClass::hLoad(char *szName,
							  LPDIRECT3DDEVICE9 p3d)
{
	HRESULT hResult = S_OK;
	int i;
	char szFullPath[256];
	D3DXMATERIAL* d3dxMaterials;

	hResult = D3DXLoadMeshFromX(szName,				//file name
								D3DXMESH_SYSTEMMEM, //create mesh in sys ram
								p3d,				//direct 3D device
								NULL,				//adjacency buffer
								&pD3DXMtrlBuffer,	//out loaded materials
								NULL,				//out special effects (none)
								&dwNumMaterial,		//number of materials (out)
								&pMesh);			//out our actual mesh (geometry)

	if (FAILED(hResult))
		return -1;

	// set a temp pointer to Material Buffer for easier
	// to read code
	d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();

	// create the material and texture arrays
	pMeshMaterials = new D3DMATERIAL9[dwNumMaterial];
	pMeshTextures = new LPDIRECT3DTEXTURE9[dwNumMaterial];

	// load the material information and textures
	for (int i = 0; i < (signed)dwNumMaterial; i++)
	{
		pMeshMaterials[i] = d3dxMaterials[i].MatD3D;
		// direct3d doesn't set the ambient color
		// so set it
		pMeshMaterials[i].Ambient = pMeshMaterials[i].Diffuse;

		sprintf(szFullPath, "Data//3DObjects??%s",
				d3dxMaterials[i].pTextureFilename);

		hResult = D3DXCreateTextureFromFile( p3d, szFullPath, &pMeshTextures[i]);

		// if the above line fails, the
		//
		//
		if (FAILED(hResult))
		{
			delete pMeshTextures[i];
			pMeshTextures[i] = NULL;
		}
	}

	SAFE_RELEASE(pD3DXMtrlBuffer);
	d3dxMaterials = NULL;
	return hResult;

}


void Object3DClass::DisplayXYZ(float x, float y, float z,
								float rx, float ry, float rz)
{
	D3DXMATRIX matWorld, matRotation, matTranslation, matScale;

	D3DXMatrixIdentity(&matTranslation);

	// aplly the rotations first then the translation
	// divide to convert to radians
	D3DXMatrixRotationX(&matRotation, rx/RADIAN_TO_DEGREES);

	D3DXMatrixMultiply(&matTranslation, // dest, combine transformatins
					   &matRotation, // M1
					   &matTranslation); // M2

	D3DXMatrixRotationY(&matRotation, ry/RADIAN_TO_DEGREES);

	D3DXMatrixMultiply(&matTranslation, // dest, combine transformatins
					   &matRotation, // M1
					   &matTranslation); // M2

	D3DXMatrixRotationZ(&matRotation, rz/RADIAN_TO_DEGREES);

	D3DXMatrixMultiply(&matTranslation, // dest, combine transformatins
					   &matRotation, // M1
					   &matTranslation); // M2

	matTranslation._41 = x;
	matTranslation._42 = y;
	matTranslation._43 = z;

	pd3dDevice->SetTransform(D3DTS_WORLD, &matTranslation);

	// loop to draw the geometry in pMesh, using the
	// mareial and texture values from the arrays
	//

	for (int m = 0; m < (signed)dwNumMaterial; m++)
	{
		pd3dDevice->SetMaterial(&pMeshMaterials[m]);
		pd3dDevice->SetTexture(0, pMeshTextures[m]);
		
		// draw the geometry
		pMesh->DrawSubset(m);

		// clear out the texture setting
		pd3dDevice->SetTexture(0, NULL);
	}
}
