#pragma once

#include <d3dx9.h>
#include "..\DPlay\Include\dplay8.h"

struct PLAYER_INFORMATION
{
	bool			bActive;
	DPNID			dpnidPLayer;
	D3DXVECTOR3		vecCurPos;
	D3DXVECTOR3		vecLastPos;
	float			fVelocity;
	long			iScore;
	int				iFrame; //what frame of animation is playing
	float			fRot;
	char			szPlayerName[32];
};

//format fo our custom vetex format
#define D3DFCF_MYVERTEX(DEDFCF_XYZ|D3DFVF_DIFFUSE | D3DFVF_TEX1)
//declaartion of our custon vertex format
typedef struct MYVERTEX
{
	D3DXVECTOR3 vecPos;
	D3DXVECTOR3 vecNorm;
	DWORD		dwDiffuse;
	float		u;
	float		v;

}MYVERTEX, *LPMYVERTEX; //aliases