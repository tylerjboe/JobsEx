#include "CRenderer.h"
#include "Game.h"

#pragma comment (lib, "d3d9.lib")
#pragma comment (lib, "d3dx9.lib")

LPDIRECT3D9   pD3D; // main d3d object
LPDIRECT3DDEVICE9 pd3dDevice; // video card device object

CRenderer::CRenderer()
{
	if (!Init())
	{
		PostQuitMessage(0);
	}
}

CRenderer::~CRenderer()
{
	if (!CleanUp())
	{
		LogString("Could no clean up after renderer");
		PostQuitMessage(0);
	}
}

bool CRenderer::CleanUp()
{
	SAFE_RELEASE(pd3dDevice);
	SAFE_RELEASE(pD3D);
	return true;
}

//draw one frame of our game
bool CRenderer::RenderFrame( float dt)
{
	if (IsDeviceLost())
		return false;
	if (pd3dDevice == NULL)
		return false;

	HRESULT hResult;
	pd3dDevice->Clear(0,
					  NULL, // rectangle to clear, NULL means whole screen
					  D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					  D3DCOLOR_XRGB(0, 0, 255),
					  1.0f, // z buffer value
					  0);   // stencil value

	hResult = pd3dDevice->BeginScene();
	//drawing goes here

	hResult = pd3dDevice->EndScene();
	//flip page and present the screen
	pd3dDevice->Present(NULL, NULL, NULL, NULL);

	return true;
}

//initialize direct3D
bool CRenderer::Init()
{
	LogString("CRenderer::Init() Initializing Direct 3D");

	//Step 1: Create the D3D Object
	pD3D = NULL;

	pD3D = Direct3DCreate9(D3D_SDK_VERSION);

	if (pD3D == NULL)
	{
		MessageBox(NULL, "Cannot Create D3D Object", "Error", MB_OK);

		LogString("CRenderer::Init() Can't Create D3D Object");
		return false;
	}

	//Step 2
	//Verify Hardware Support for fullscreen and windowed
	//(Resolution, Refresh Rate, Color Depth)
	D3DDISPLAYMODE mode;
	D3DDEVTYPE d3dDevType;
	d3dDevType = D3DDEVTYPE_HAL;

	//get the current video settings
	pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &mode);

	//check if the current display mode is supported
	//in direct3D in windowed and fullscreen mode
	HRESULT hr;

	hr = pD3D->CheckDeviceType(D3DADAPTER_DEFAULT, 
							   d3dDevType, //device type (HAL)
							   mode.Format, //adapter format
							   mode.Format, //back buffer format
							   true); //windowed

	if (hr != S_OK)
	{
		LogString("Renderer::Init Cannot Determine if mode will work in windowed!");
	}

	pD3D->CheckDeviceType(D3DADAPTER_DEFAULT, 
						  d3dDevType, //device type (HAL)
						  D3DFMT_X8R8G8B8, //adapter format
						  D3DFMT_X8R8G8B8, //back buffer format
						  false); //fullscreen

	if (hr != S_OK)
	{
		LogString("Renderer::Init Cannot Determine if mode will work in fullscreen!");
	}

	//Step 3
	//Check Device Capabilities (Pure Device)

	D3DCAPS9 caps;
	hr = pD3D->GetDeviceCaps(D3DADAPTER_DEFAULT,
							 d3dDevType,
							 &caps);

	if (hr != S_OK)
	{
		LogString("Renderer::Init Can't get device caps!");
		return false;
	}

	DWORD devBehaviorFlags = 0; //fill in to create device

	if (caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT)
		devBehaviorFlags = D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		devBehaviorFlags = D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	if (caps.DevCaps & D3DDEVCAPS_PUREDEVICE && devBehaviorFlags & D3DCREATE_HARDWARE_VERTEXPROCESSING)
		devBehaviorFlags = D3DCREATE_PUREDEVICE;

	//Step 4
	//Fill in a presentation parameters structure
	//using the info from step 2 and 3
	//we will use this structure to create our
	//video card device interface
	d3dpp.BackBufferWidth = gGame->gWin->mWidth;
	d3dpp.BackBufferHeight = gGame->gWin->mHeight;
	d3dpp.BackBufferCount = 1;
	d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE;
	d3dpp.MultiSampleQuality = 0;
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD; // discard buffer info after every draw
	d3dpp.hDeviceWindow = gGame->gWin->GetHandle();
	d3dpp.EnableAutoDepthStencil = true;
	d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8;
	d3dpp.Flags = 0;
	d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	//TODO: if windowed
		d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
		d3dpp.Windowed = true;
	//if fullscreen
		//d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
		//d3dpp.Windowed = false;

	//Step 5
	//Create the direct3D device (the video card object)
	
	hr = pD3D->CreateDevice(D3DADAPTER_DEFAULT,
						d3dDevType,
						gGame->gWin->GetHandle(),
						devBehaviorFlags,
						&d3dpp,
						&pd3dDevice);

	if FAILED(hr) //means same as if (hr != S_OK)
	{
		LogString("Renderer::Init Critical Error can't create d3dDevice!!!");
		return false;
	}

	return true;
}

void CRenderer::setupOrthoCamera()
{

	float width = gGame->gWin->mWidth;
	float heigth = gGame->gWin->mHeight;

	D3DXMATRIX matOrtho;
	D3DXMATRIX matIdentity;

	//set up the orthographic matrix
	D3DXMatrixOrthoLH(&matOrtho,	// out, what we get back
					  width,
					  heigth,
					  0.0f,			// near plane
					  100.0f);		// far plane

	D3DXMatrixIdentity(&matIdentity);

	// tell ditrect3D what matrices to use for our transformation
	pd3dDevice->SetTransform(D3DTS_PROJECTION,
						     &matOrtho);

	pd3dDevice->SetTransform(D3DTS_VIEW,
						     &matIdentity);

	pd3dDevice->SetTransform(D3DTS_WORLD,	// modeling trans
						     &matIdentity);

	//setup sampling states for minification
	//magnification and mip maps
	pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT); //magnification

	pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT); //minification

	pd3dDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);  //mip map

	pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

	pd3dDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);

	pd3dDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
}

//make sure video device is still available
bool CRenderer::IsDeviceLost()
{
	//get the state of the graphics device
	//possible code states:
	// 1. device is lost - wait a bit
	// 2. we have a driver error - exit the program
	// 3. the device is lost but we can reset it
	// 4. no errors

	HRESULT hr = pd3dDevice->TestCooperativeLevel();

	if (hr == D3DERR_DEVICELOST)
	{
		Sleep(20);
		return true;
	} else if ( hr == D3DERR_DRIVERINTERNALERROR)
	{
		MessageBox(NULL, "Internal driver error...exiting", "Error!!!", MB_OK);
		LogString("Video Driver error!!");
		PostQuitMessage(0); //send a WM_QUIT windows message
		return true;
	} else if (hr == D3DERR_DEVICENOTRESET)
	{
		//reset the device with the presentation parameters from Init(). 
		//Call OnLostDevice() and OnResetDevice() to ensure game specific
		//classes are reset (Sprites, Fonts, etc.)
		onLostDevice();
		pd3dDevice->Release();
		onResetDevice();
		return false; //device is no longer lost
	} else
	{
		return false; //no errors and device is not lost
	}
}

void CRenderer::onLostDevice()
{
	// mFont->onLostDevice()
}

void CRenderer::onResetDevice()
{
	// mFont->onResetDevice()
	setupOrthoCamera();
}


void CRenderer::loadResources()
{
	char szFN[256];
	//load the ship models
	//Object3dClass type
	for(int i = 0; i <12; i++)
	{
		sprintf(szFN, "data\\3DObjects\\droid%d.x", i);
		o3dShip[i].hLoad(szFn, pd3dDevice);
	}

	//load the arena vertices
	// arena will be 50 x 50.
	//gVertices holds the corners
	//				25
	//				|
	//			-25------25
	//				|
	//				-25
	
	int fHeight = 50;
	int fWidth = 50;

	//upper left
	g_Vertices[0].vecPos = D3DXVECTOR3(-fWidth/2, fHeight/2,0.0f);
	g_Vertices[0].u = 0.0f;
	g_Vertices[0].v = 0.0f;
	g_Vertices[0].dwDiffuse = D3DCOLOR_XRGB(255, 255, 255);
	g_Vertices[0].vecNorm =	D3DXVECTOR3(0.0f,0.0f,1.0f);
	//LOWERLEFT
	g_Vertices[1].vecPos = D3DXVECTOR3(-fWidth/2, -fHeight/2,0.0f);
	g_Vertices[1].u = 0.0f;
	g_Vertices[1].v = 1.0f;
	g_Vertices[1].dwDiffuse = D3DCOLOR_XRGB(255, 255, 255);
	g_Vertices[1].vecNorm =	D3DXVECTOR3(0.0f,0.0f,1.0f);

	//UPPER RIGHT
	g_Vertices[2].vecPos = D3DXVECTOR3(fWidth/2, fHeight/2,0.0f);
	g_Vertices[2].u = -1.0f;
	g_Vertices[2].v = 0.0f;
	g_Vertices[2].dwDiffuse = D3DCOLOR_XRGB(255, 255, 255);
	g_Vertices[2].vecNorm =	D3DXVECTOR3(0.0f,0.0f,1.0f);

	//bottom RIGHT
	g_Vertices[3].vecPos = D3DXVECTOR3(fWidth/2, -fHeight/2,0.0f);
	g_Vertices[3].u = -1.0f;
	g_Vertices[3].v = 1.0f;
	g_Vertices[3].dwDiffuse = D3DCOLOR_XRGB(255, 255, 255);
	g_Vertices[3].vecNorm =	D3DXVECTOR3(0.0f,0.0f,1.0f);

	//create the vertex buffer for our arena geometry
	HRESULT hr;
	hr = pd3dDevice->CreateVertexBuffer(4 * sizeof(MYVERTEX),
		0, D3DFVF_MYVERTEX, D3DPOOL_DEFAULT,
		&lpVertexBuffer, NULL);
	if(FAILED(hr))
		return;
	//copy the vertices over
	//first lock the memory and get pointer
	void* lpLockedVertices;
	hr = lpVertexBuffer->Lock(0, //lock from beginning
			sizeof(g_Vertices), //how much to lock
			(void **)&lpLockedVertices, //the pointer to area
			0); //flags read only write etc
	if (FAILED(hr))
		return;

	memcpy(lpLockedVertices, g_Vertices,sizeof(g_Vertices));

	lpVertexBuffer->Unlock();


	//load the explosion textures
	
	//load misc tectures

	//crate the font
}

//d3dxvector3 vecpos
