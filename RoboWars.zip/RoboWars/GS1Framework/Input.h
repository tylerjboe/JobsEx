#pragma once
// We need direct input for joystick control.
// Microsoft recommends switching to normal windows
// libraries for keyboard and mouse, but you need
// direct input for gamepad. If your game doesn't
// use gamepad, then use normal windows
// getasynckeystate mechanisms

#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>
#include <dinputd.h>

class CInput
{
public:
	CInput(HWND wHandle, HINSTANCE hInstance);
	~CInput(void);

	IDirectInput8* m_dInput; //main direct input object

	IDirectInputDevice8* m_GamePad;
	DIJOYSTATE2			 m_GamePadState;

	IDirectInputDevice8* m_Mouse;
	DIMOUSESTATE2		 m_MouseState;

	IDirectInputDevice8* m_Keyboard;
	char				 m_KeyboardState[256];

private:
	// prevent copying of class object
	CInput(const CInput& rhs);
	CInput& operator=(const CInput& rhs);

	DIDEVCAPS m_GamePadCaps;
};

BOOL CALLBACK EnumJoysticksCallback(
	const DIDEVICEINSTANCE* pdidInstance, VOID* pContext){return true;}

BOOL CALLBACK EnumJoystickAxisCallback(
	const DIDEVICEOBJECTINSTANCE* pdidoInstance, VOID* pContext){return true;}
