#pragma once
#include <Windows.h>
#include "constants.h"
#include "Util.h"
#include "..\DPlay\Include\dplay8.h"
#include "DataTypes.h"

class PacketGeneric
{
public:
	DWORD dwType;
	DWORD dwSize;
};

class PacketChat : public PacketGeneric
{
public:
	char szText[128];
};

class PacketAngle : public PacketGeneric
{
public:
	float fAngle;
};

class PacketVelocity : public PacketGeneric
{
public:
	float fVelocity;
};

class PacketPosition : public PacketGeneric
{
public:
	float fx;
	float fz;
};

class PacketBullet : public PacketGeneric
{
public:
	BulletObject Bullet;
};

class PacketScore : public PacketGeneric
{
public:
	long lScore;
};

HRESULT WINAPI DirectPlayMessageHandler(PVOID pvUserContext, DWORD dwMessageId, PVOID pMsgBuffer);

class Network
{
public:
	Network();
	~Network();
	bool Initialize(HWND hWnd);
	bool Cleanup();
	void UpdateNetwork(); //called each cycle

	HRESULT SendPeerMessage(int player, DWORD dwMessageType, PVOID pMsgBuffer);

	HRESULT HostGame(HWND hWnd);
	HRESULT JoinGame(HWND hWnd);
	int		iAddPlayer(DPNID dpid, D3DXVECTOR3 pos, float fRot, char *szName);
	HRESULT CreatePlayer(PVOID pvUserContext, PVOID pMsgBuffer);
	HRESULT DestroyPlayer(PVOID pvUserContext, PVOID pMsgBuffer);

	IDirectPlay8Peer*		pDP;
	IDirectPlay8Address*    pDeviceAddress; //us
	IDirectPlay8Address*    pHostAddress;   //our host
	DPNHANDLE				hConnectAsycOp;
	DPNID					dpnidLocalPlayer;
	PLAYER_INFORMATION		PlayerInfo[MAX_PLAYERS];    
	int						iMyPlayerId; //subscript into player
	LONG					lNumberOfActivePlayers;
	bool					bHost; // are we the Host?

};

//multi-threading variables
extern HANDLE				gConnectCompleteEvent;
extern HRESULT				gConnectComplete;
extern CRITICAL_SECTION		gModifyPlayer;