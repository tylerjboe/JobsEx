#include "WindowClass.h"
#include "Util.h"

WindowClass::WindowClass(HINSTANCE hInstance, int Width, int Height, bool FullScreen, std::string WindowName)
{
	mIsCreated = false;
	mhInstance = hInstance;
	mWidth = Width;
	mHeight = Height;
	mFullScreen = FullScreen;
	mWindowName = WindowName;

	if(!initWindow())
	{
		LogString("Could Not Create Window");
		PostQuitMessage(0);
	}
	mIsCreated = true;
}

WindowClass::WindowClass(HINSTANCE hInstance)
{
	mIsCreated = false;
	mhInstance = hInstance;
	mWidth = 640;
	mHeight = 480;
	mFullScreen = false;
	mWindowName = "Window";

	if(!initWindow())
	{
		LogString("Could Not Create Window");
		PostQuitMessage(0);
	}
	mIsCreated = true;
	LogString("Window Created");
}


bool WindowClass::initWindow()
{


	WNDCLASSEX wcsex;
	wcsex.cbSize = sizeof(WNDCLASSEX);
	wcsex.style			= CS_HREDRAW | CS_VREDRAW;
	wcsex.lpfnWndProc	= (WNDPROC)WndProc;
	wcsex.cbClsExtra	= 0;
	wcsex.cbWndExtra	= 0;
	wcsex.hInstance		= mhInstance;
	wcsex.hIcon			= 0;
	wcsex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcsex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcsex.lpszMenuName	= NULL;
	wcsex.lpszClassName	= mWindowName.c_str();
	wcsex.hIconSm		= 0;
	RegisterClassEx(&wcsex);


	// create window either full screen or windowed
	DWORD      dwWindowStyle;
	if (mFullScreen)
	{
	dwWindowStyle = WS_EX_TOPMOST | WS_POPUP | WS_VISIBLE;
	}else{
	dwWindowStyle = WS_OVERLAPPEDWINDOW;
	}

	mwHandle = CreateWindow(mWindowName.c_str(), 
							mWindowName.c_str(), 
							 dwWindowStyle,
							 CW_USEDEFAULT, //x 
							 CW_USEDEFAULT, //y
							 mWidth, 
							 mHeight, 
							 NULL, 
							 NULL, 
							 mhInstance, 
							 NULL);
	
   if (!mwHandle) // if program cant create window
   {
      return false;
   }
   
   ShowWindow(mwHandle, SW_SHOW);
   UpdateWindow(mwHandle);

   return true;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) 
	{
		case WM_DESTROY:
			PostQuitMessage(0);
			break;

		case WM_LBUTTONDOWN:		// left mouse button
			break;

		case WM_RBUTTONDOWN:		// right mouse button
			break;

		case WM_MOUSEMOVE:			// mouse movement
			break;

		case WM_LBUTTONUP:			// left button release
			break;

		case WM_RBUTTONUP:			// right button release
			break;

		case WM_KEYUP:
			break;

		case WM_KEYDOWN:
			int fwKeys;
			LPARAM keyData;
			fwKeys = (int)wParam;    // virtual-key code 
			keyData = lParam;          // key data 

			switch(fwKeys)
			{
			case VK_ESCAPE:
				PostQuitMessage(0);
				break;

			case 0x46: // f key
				PostMessage(hWnd, WM_FLIPWINSTATE, 0, 0);
				break;
			default:
				break;
			}

			break;

		default:
			break;

	}
		return DefWindowProc(hWnd, message, wParam, lParam);
}





