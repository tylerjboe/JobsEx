#ifndef __WINDOWCLA
#define __WINDOWCLA

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <string>
#include "Util.h"

#define WM_FLIPWINSTATE  WM_USER + 4
#define WM_EXITGAME		 WM_USER + 5

class WindowClass
{
public:
	HINSTANCE mhInstance;
	int mWidth;
	int mHeight;
	bool mFullScreen;
	bool mIsCreated;
	std::string mWindowName;
	HWND mwHandle;

	WindowClass(HINSTANCE hInstance,
		    int Width,
			int Height,
			bool FullScreen,
			std::string WindowName);

	WindowClass(HINSTANCE hInstance);

    HINSTANCE GetInstance() 
	{ 
		return mhInstance;
	}
	
	HWND GetHandle() 
	{
		return mwHandle;
	}
	
private:
	bool initWindow();

};

LRESULT CALLBACK WndProc(HWND hWnd,
						 UINT message,
						 WPARAM wParam,
						 LPARAM lParam);

#endif